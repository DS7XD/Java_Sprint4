package sprint4.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sprint4.model.vo.Automovel;

@Repository
public interface AutomovelDAO extends JpaRepository<Automovel, Long> {
    
}

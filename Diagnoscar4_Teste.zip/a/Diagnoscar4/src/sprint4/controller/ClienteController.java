package sprint4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sprint4.model.dao.ClienteDAO;
import sprint4.model.vo.Cliente;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private ClienteDAO clienteDAO;

    // GET para listar todos os clientes
    @GetMapping
    public List<Cliente> listarClientes() {
        return clienteDAO.listarTodos();
    }

    // GET para buscar um cliente por ID
    @GetMapping("/{id}")
    public Cliente buscarClientePorId(@PathVariable int id) {
        return clienteDAO.buscarPorId(id);
    }

    // POST para adicionar um novo cliente
    @PostMapping
    public String adicionarCliente(@RequestBody Cliente cliente) {
        clienteDAO.inserir(cliente);
        return "Cliente adicionado com sucesso!";
    }

    // PUT para atualizar um cliente existente
    @PutMapping("/{id}")
    public String atualizarCliente(@PathVariable int id, @RequestBody Cliente cliente) {
        Cliente existente = clienteDAO.buscarPorId(id);
        if (existente != null) {
            existente.setNome(cliente.getNome());
            clienteDAO.atualizar(existente);
            return "Cliente atualizado com sucesso!";
        }
        return "Cliente não encontrado!";
    }

    // DELETE para remover um cliente
    @DeleteMapping("/{id}")
    public String removerCliente(@PathVariable int id) {
        Cliente existente = clienteDAO.buscarPorId(id);
        if (existente != null) {
            clienteDAO.remover(id);
            return "Cliente removido com sucesso!";
        }
        return "Cliente não encontrado!";
    }
}


package sprint4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sprint4.model.dao.ClienteDAO;
import sprint4.model.vo.Cliente;

@RestController
@RequestMapping("/api/login")
public class LoginController {

    @Autowired
    private ClienteDAO clienteDAO;

    // POST para verificar login
    @PostMapping
    public String login(@RequestParam String email, @RequestParam String senha) {
        Cliente cliente = clienteDAO.buscarPorEmail(email);
        if (cliente != null && cliente.getSenha().equals(senha)) {
            return "Login bem-sucedido";
        }
        return "Email ou senha incorretos";
    }
}


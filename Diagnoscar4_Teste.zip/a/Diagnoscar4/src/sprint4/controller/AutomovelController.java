package sprint4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sprint4.model.vo.Automovel;
import sprint4.model.dao.AutomovelDAO;

import java.util.List;

@RestController
@RequestMapping("/api/automoveis")
public class AutomovelController {

    @Autowired
    private AutomovelDAO automovelDAO;

    // GET para listar todos os automóveis
    @GetMapping
    public List<Automovel> listarAutomoveis() {
        return automovelDAO.listarTodos();
    }

    // GET para buscar um automóvel por ID
    @GetMapping("/{id}")
    public Automovel buscarAutomovelPorId(@PathVariable int id) {
        return automovelDAO.buscarPorId(id);
    }

    // POST para adicionar um novo automóvel
    @PostMapping
    public String adicionarAutomovel(@RequestBody Automovel automovel) {
        automovelDAO.inserir(automovel);
        return "Automóvel adicionado com sucesso!";
    }

    // PUT para atualizar um automóvel existente
    @PutMapping("/{id}")
    public String atualizarAutomovel(@PathVariable int id, @RequestBody Automovel automovel) {
        Automovel existente = automovelDAO.buscarPorId(id);
        if (existente != null) {
            // Atualize os atributos conforme necessário
            existente.setModelo(automovel.getModelo());
            automovelDAO.atualizar(existente);
            return "Automóvel atualizado com sucesso!";
        }
        return "Automóvel não encontrado!";
    }

    // DELETE para remover um automóvel
    @DeleteMapping("/{id}")
    public String removerAutomovel(@PathVariable int id) {
        Automovel existente = automovelDAO.buscarPorId(id);
        if (existente != null) {
            automovelDAO.remover(id);
            return "Automóvel removido com sucesso!";
        }
        return "Automóvel não encontrado!";
    }
}

